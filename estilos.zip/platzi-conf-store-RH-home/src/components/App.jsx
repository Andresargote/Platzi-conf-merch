import React from 'react';

const App = () => <h1>Hola Mundo</h1>;

export default App;
