import React from 'react';

const Checkout = () => {
  return (
    <h1>Checkout</h1>
  );
}

export default Checkout;