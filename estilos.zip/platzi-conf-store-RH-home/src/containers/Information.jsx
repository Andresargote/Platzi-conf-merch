import React from 'react';

const Information = () => {
  return (
    <h1>Information</h1>
  );
}

export default Information;