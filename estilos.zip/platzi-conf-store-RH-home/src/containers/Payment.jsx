import React from 'react';

const Payment = () => {
  return (
    <h1>Payment</h1>
  );
}

export default Payment;